$(document).ready(function ($) {
    "use strict";



    

}(jQuery));